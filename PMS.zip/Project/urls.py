from django.urls import path

from . import views

urlpatterns = [
    path('', views.ProjectListView.as_view(), name='project_list'),
    path('project/<int:pk>/', views.ProjectDetailView.as_view(), name='project_detail'),
    path('project/create/', views.ProjectCreateView.as_view(), name='project_create'),
    path('project/<int:pk>/edit/', views.ProjectUpdateView.as_view(), name='project_edit'),
    path('project/<int:pk>/delete/', views.ProjectDeleteView.as_view(), name='project_delete'),
    path('project/<int:project_id>/ait/add/', views.AITCreateView.as_view(), name='add-ait'),
    path('project/<int:project_id>/ait/<int:pk>/edit', views.AITUpdateView.as_view(), name='edit-ait'),
    path('project/<int:project_id>/ait/<int:pk>/delete', views.AITDeleteView.as_view(), name='delete-ait'),
    path('project/<int:project_id>/create-benchmarks/', views.BenchmarkCreateView.as_view(), name='create-benchmarks'),
    path('projects/<int:project_id>/benchmarks/', views.load_benchmarks_by_date, name='load_benchmarks_by_date')

]
