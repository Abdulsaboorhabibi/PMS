from django.contrib import admin
from . import models


admin.site.register(models.Project)
admin.site.register(models.AIT)
admin.site.register(models.Benchmark)
admin.site.register(models.Achievement)
