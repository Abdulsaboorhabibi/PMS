from django.db import models


class Project(models.Model):
    title = models.CharField(max_length=1000)
    description = models.CharField(max_length=1000, blank=True, null=True)
    start_date = models.DateField()
    end_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    province = models.CharField(max_length=1200, blank=True, null=True)
    district = models.CharField(max_length=1200, blank=True, null=True)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['start_date']


class AIT(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='aits')
    activity = models.CharField(max_length=1000)
    indicator = models.CharField(max_length=1000)
    target = models.CharField(max_length=1000)
    IsCompleted = models.BooleanField(default=False)

    def __str__(self):
        return self.activity

    class Meta:
        ordering = ['project']


class Benchmark(models.Model):
    AIT = models.ForeignKey(AIT, on_delete=models.CASCADE, related_name='benchmarks')
    description = models.TextField(max_length=1000, blank=True, null=True)
    target_date = models.DateField()
    men = models.IntegerField(default=0)
    women = models.IntegerField(default=0)
    girls = models.IntegerField(default=0)
    boys = models.IntegerField(default=0)
    disabled = models.IntegerField(default=0)

    def __str__(self):
        return self.target_date

    class Meta:
        ordering = ['target_date']


class Achievement(models.Model):
    benchmark = models.ForeignKey(Benchmark, on_delete=models.CASCADE, related_name='achievements')
    description = models.TextField(max_length=1000, blank=True, null=True)
    achievement_date = models.DateField()
    target_benchmark_date = models.DateField()
    men = models.IntegerField(default=0)
    women = models.IntegerField(default=0)
    girls = models.IntegerField(default=0)
    boys = models.IntegerField(default=0)
    disabled = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Achievement for {self.benchmark} on {self.achievement_date}"
    
    class Meta:
        ordering = ['achievement_date']