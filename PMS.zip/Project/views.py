from datetime import datetime

from django.contrib import messages
from django.db.models import Prefetch
from django.forms import modelformset_factory
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.template.loader import render_to_string
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, View

from .forms import ProjectForm, AITForm, BenchmarkForm
from .models import Project, AIT, Benchmark


class ProjectListView(ListView):
    model = Project
    template_name = 'Project/project_list.html'
    context_object_name = 'projects'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['now'] = datetime.now().date()  # Pass current datetime
        context['count'] = Project.objects.all().count()
        return context


class ProjectDetailView(DetailView):
    model = Project
    template_name = 'Project/project_detail.html'
    context_object_name = 'project'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['now'] = datetime.now().date()  # Pass current datetime
        context['AITs'] = AIT.objects.filter(project=self.object)

        # Get distinct dates of benchmarks for this project
        distinct_dates = Benchmark.objects.filter(
            AIT__project=self.object
        ).order_by('-target_date').values_list('target_date', flat=True).distinct()
        context['benchmark_dates'] = distinct_dates
        return context


class ProjectCreateView(CreateView):
    model = Project
    form_class = ProjectForm
    template_name = 'Project/project_form.html'
    success_url = '/'

    def form_valid(self, form):
        messages.success(self.request, 'Project created successfully!')
        return super().form_valid(form)


class ProjectUpdateView(UpdateView):
    model = Project
    template_name = 'Project/project_form.html'
    form_class = ProjectForm
    success_url = '/'

    def form_valid(self, form):
        messages.success(self.request, 'Project updated successfully!')
        return super().form_valid(form)


class ProjectDeleteView(DeleteView):
    model = Project
    template_name = 'Project/project_confirm_delete.html'
    extra_context = {'now': datetime.now().date()}
    success_url = '/'

    def form_valid(self, form):
        messages.success(self.request, 'Project deleted successfully!')
        return super().form_valid(form)


class AITCreateView(CreateView):
    model = AIT
    form_class = AITForm
    template_name = 'Project/ait_form.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['project_id'] = self.kwargs['project_id']
        return context

    def form_valid(self, form):
        form.instance.project_id = self.kwargs['project_id']
        messages.success(self.request, 'AIT created successfully.')
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('project_detail', kwargs={'pk': self.kwargs['project_id']})


class AITUpdateView(UpdateView):
    model = AIT
    form_class = AITForm
    template_name = 'Project/ait_form.html'

    def form_valid(self, form):
        form.instance.pk = self.kwargs['pk']
        form.instance.project_id = self.kwargs['project_id']
        messages.success(self.request, 'AIT created successfully.')
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('project_detail', kwargs={'pk': self.object.project.id})

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['project_id'] = self.object.project.id
        return context


class AITDeleteView(DeleteView):
    model = AIT
    template_name = 'Project/ait_confirm_delete.html'

    def get_success_url(self):
        return reverse_lazy('project_detail', kwargs={'pk': self.object.project.id})

    def form_valid(self, form):
        messages.success(self.request, 'AIT deleted successfully!')
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['project_id'] = self.object.project.id
        return context


class BenchmarkCreateView(View):
    template_name = "Project/create_benchmarks.html"

    def get(self, request, project_id):
        project = get_object_or_404(Project, pk=project_id)
        list_ait = project.aits.all()
        benchmark_formset = modelformset_factory(Benchmark, form=BenchmarkForm, extra=1)

        ait_formsets = []
        for ait in list_ait:
            formset = benchmark_formset(queryset=Benchmark.objects.none(), prefix=f'ait_{ait.id}')
            ait_formsets.append((ait, formset))

        return render(request, self.template_name, {'project': project , 'ait_formsets': ait_formsets})

    def post(self, request, project_id):
        project = get_object_or_404(Project, pk=project_id)
        list_ait = project.aits.all()

        benchmark_formsets = modelformset_factory(Benchmark, form=BenchmarkForm, extra=1)
        valid = True
        ait_formsets = []

        # 🔑 Get the selected date from the form
        raw_target_date = request.POST.get('target_date')
        target_date = datetime.strptime(raw_target_date, '%Y-%m').date()

        exists = Benchmark.objects.filter(target_date=target_date).exists()
        if exists:
            valid = False
            messages.error(request, 'Target date already exists!')

        for ait in list_ait:
            formset = benchmark_formsets(request.POST, prefix=f'ait_{ait.id}')
            print(f"Errors for AIT {ait.id}: {formset.errors}")
            ait_formsets.append((ait, formset))

            if formset.is_valid():
                benchmarks = formset.save(commit=False)
                for benchmark in benchmarks:
                    benchmark.AIT = ait
                    benchmark.target_date = target_date
                    benchmark.save()

                messages.success(request, 'Benchmark created successfully!')
            else:
                valid = False
        if valid:
            return  redirect('project_detail', pk=project_id)
        return render(request, self.template_name, {'project': project , 'ait_formsets': ait_formsets})

from django.utils.dateparse import parse_date

def load_benchmarks_by_date(request, project_id):
    raw_selected_date = request.GET.get('selected_date')

    try:
        # Try to parse Aug 1, 2025, or similar formats
        try:
            # Remove dot if it exists in month
            raw_selected_date = raw_selected_date.replace(".", "")
            selected_date = datetime.strptime(raw_selected_date, "%b %d, %Y").date()
        except ValueError:
            # If it's already in YYYY-MM-DD (safe fallback)
            selected_date = parse_date(raw_selected_date)

    except Exception as e:
        return HttpResponse(f"<div class='text-danger'>Invalid date: {e}</div>")

    if not selected_date:
        return HttpResponse("<div class='text-danger'>No valid date selected.</div>")

    project = get_object_or_404(Project, pk=project_id)

    # AITs with filtered Benchmarks
    aits = AIT.objects.filter(project=project).prefetch_related(
        Prefetch(
            'benchmarks',
            queryset=Benchmark.objects.filter(
                target_date=selected_date
            ),
            to_attr='filtered_benchmarks'
        )
    )

    html = render_to_string('partials/benchmark_by_date.html', {
        'aits': aits,
    })

    return HttpResponse(html)

