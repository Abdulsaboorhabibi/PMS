from django import forms
from Project import models

class ProjectForm(forms.ModelForm):
    class Meta:
        model = models.Project
        fields = ['title', 'start_date', 'end_date', 'province', 'district','description' ]
        labels = {
            'title': 'Project Title',
            'description': 'Project Description',
            'start_date': 'Start Date',
            'end_date': 'End Date',
            'province': 'Province Name',
            'district': 'District Name',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control col-12', 'placeholder': 'Enter project title' }),
            'start_date': forms.DateInput(attrs={ 'type': 'date', 'class': 'form-control col-12 col-md-6' }),
            'end_date': forms.DateInput(attrs={ 'type': 'date', 'class': 'form-control col-12 col-md-6' }),
            'province': forms.TextInput(attrs={'class': 'form-control col-12 col-md-6', 'placeholder': 'Enter province'}),
            'district': forms.TextInput(attrs={'class': 'form-control col-12 col-md-6', 'placeholder': 'Enter district'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Enter project description', 'rows': 3 }),
        }


class AITForm(forms.ModelForm):
    class Meta:
        model = models.AIT
        fields = ['activity', 'indicator', 'target', 'IsCompleted']
        labels = {
            'activity': 'Activity Title',
            'indicator': 'Indicator Title',
            'target': 'Target Title',
            'IsCompleted': 'Is Completed',
        }
        widgets = {
            'activity': forms.TextInput(attrs={'class': 'form-control col-12', 'placeholder': 'Enter project activity title' }),
            'indicator': forms.TextInput(attrs={ 'class': 'form-control col-12 col-md-6', 'placeholder': 'Enter project indicator title' }),
            'target': forms.TextInput(attrs={  'class': 'form-control col-12 col-md-6', 'placeholder': 'Enter project target title' }),
            'IsCompleted': forms.CheckboxInput(attrs={'class': 'form-check-input col-12 col-md-6', 'placeholder': 'Is Completed' }),
        }


class BenchmarkForm(forms.ModelForm):
    class Meta:
        model = models.Benchmark
        fields = ['description', 'men', 'women', 'girls', 'boys', 'disabled']
        labels = {
            'description': 'Benchmark Description',
            'men': 'Men',
            'women': 'Women',
            'girls' : 'Girls',
            'boys' : 'Boys',
            'disabled': 'Disabled',
        }

        widgets = {
            'description': forms.Textarea(attrs={'rows': '2', 'class': 'form-control', 'placeholder': 'Enter benchmark description' }),
            'men' : forms.TextInput(attrs={'type': 'number', 'class': 'form-control', 'placeholder': 'Enter benchmark men' }),
            'women' : forms.TextInput(attrs={'type': 'number', 'class': 'form-control', 'placeholder': 'Enter benchmark women' }),
            'girls': forms.TextInput(attrs={'type': 'number', 'class' : 'form-control', 'placeholder' : 'Enter benchmark girls'}),
            'boys' : forms.TextInput(attrs={'type': 'number', 'class' : 'form-control ', 'placeholder' : 'Enter benchmark boys' }),
            'disabled': forms.TextInput(attrs={'type': 'number', 'class': 'form-control ', 'placeholder': 'Disabled' }),
        }